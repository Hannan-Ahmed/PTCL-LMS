import React, { useState } from 'react'

function Check() {

  const [name, setName] = useState('');
  
  let option=false;
  
  const nameChange = e => (
    setName(e.target.value)
    );
    
    
    if(name.length!=13)
    {
      console.log('true')
      option=true
    }

    const [credentials,setcredentials]=useState({otp:""})
    
    const onChange=(e)=>{
      setcredentials({...credentials,[e.target.name]:e.target.value})
    }




    return (
      <div className="App">
      <input value={name} onChange={nameChange} placeholder="Cnic"/> 
      <button disabled={option}>Search</button>
      {/* <input value={credentials.otp} onChange={onChange}  id="otp" name='otp' placeholder="otp"/>
      <button onClick={handlesubmit}>Search</button> */}
    </div>
  )
}

export default Check
