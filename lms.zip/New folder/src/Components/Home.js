import React from 'react'

const Home = () => {
  return (
    <div>
      Hi this is a Home component
    </div>
  )
}

export default Home
