import React ,{useState} from 'react'
import { useNavigate } from 'react-router-dom';
function Verify() {
  const navigate = useNavigate();
    const [credentials,setcredentials]=useState({otp:""})
   
   
   
    const handlesubmit=async(e)=>{
        e.preventDefault();
        const response = await fetch(`http://localhost:5000/api/auth/votp`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }, 
        body: JSON.stringify({otp:credentials.otp}) 
      });
      const json=await response.json();
       if(json.veri)
      {
          navigate('/success');
         console.log('OTP Successed')
        }
        else
        {   
          console.log('OTP Failed')
       }
    }




    const handlesubmit2=async(e)=>{
      e.preventDefault();
      const response = await fetch(`http://localhost:5000/api/auth/rotp`, {
      method: 'POST', 
      // body: JSON.stringify({otp:credentials.otp}) 
    });
    const json=await response.json();

  }





    const onChange=(e)=>{
      setcredentials({...credentials,[e.target.name]:e.target.value})
    }



  return (
    <div>
       <input  value={credentials.otp} onChange={onChange}  id="otp" name='otp' placeholder="otp"/>
      
      <div className='container col-md-3'> 
      <button onClick={handlesubmit} className='mx-3 my-3'>Verfiy</button>
      <button onClick={handlesubmit2}>resend</button>
      </div>


    </div>
  )
}

export default Verify
