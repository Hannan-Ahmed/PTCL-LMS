import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
function Inbox() {
  let option=false;
  const navigate = useNavigate();

  const [credentials, setcredentials] = useState({ firstname: "", lastname: "", email: "", cnic: "", designation: "", contactno: "", password: "", status: "false" })
  // const navigate = useNavigate();
  const handleSubmit = async (e) => {
    e.preventDefault(); 
    const { firstname, cnic, email, lastname, designation, contactno, password, status } = credentials;

    const response = await fetch(`http://localhost:5000/api/auth/createuser`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      // body: JSON.stringify({firstname,lastname,email,contactno,cnic,designation,password,cpassword}) 
      body: JSON.stringify({ firstname, lastname, email, contactno, cnic, designation, password ,status})
    });
    const json = await response.json();
    console.log(json);
    if (json.success) {
      // storing the tocken locally
      localStorage.setItem('token', json.authtoken);
      // navigate('/home');
      console.log("SIGNED UP");
    }
    else {
      alert('Worong Credentials !')
    }
      




    const response2 = await fetch(`http://localhost:5000/api/auth/gotp`, {
      method: 'POST', 
    
      headers: {
        'Content-Type': 'application/json'
      },
      
  body: JSON.stringify({email}) 
    });

    const json2=await response2.json();
    
      if (!json2.sta) {
         
        console.log("Otp Not Sent");
        
      }
      else{
        
        console.log("OTP SENT");
         navigate('/verify');
            
        }






  }


  const onChange = (e) => {
    setcredentials({ ...credentials, [e.target.name]: e.target.value })
    
  }
  return (
    <div className='col-md-5 mx-5 my-4'>
      <form className=' mx-5 my-4' onSubmit={handleSubmit}>
        <div className="mb-3 ">
          <label htmlFor="firstname" className="form-label">First Name</label>
          <input onChange={onChange} className="form-control" id="firstname" name='firstname' aria-describedby="emailHelp" />
        </div>
        <div className="mb-3 ">
          <label htmlFor="lastname" className="form-label">Last Name</label>
          <input onChange={onChange} className="form-control" id="lastname" name='lastname' aria-describedby="emailHelp" />
        </div>
        <div className="mb-3 ">
          <label htmlFor="contactno" className="form-label">Contact</label>
          <input onChange={onChange} className="form-control" id="contactno" name='contactno' aria-describedby="emailHelp" />
        </div>
        <div className="mb-3 ">
          <label htmlFor="cnic" className="form-label">Cnic</label>
          <input onChange={onChange} className="form-control" id="cnic" name='cnic' aria-describedby="emailHelp" />
        </div>
        <div className="mb-3 ">
          <label htmlFor="designation" className="form-label">Designation</label>
          <input onChange={onChange} className="form-control" id="designation" name='designation' aria-describedby="emailHelp" />
        </div>
        <div className="mb-3">
          <label htmlFor="email" className="form-label">Email</label>
          <input onChange={onChange} className="form-control" id="email" name='email' aria-describedby="emailHelp" />
        </div>
        <div className="mb-3">
          <label htmlFor="password" className="form-label">Password</label>
          <input onChange={onChange} className="form-control" id="password" name='password' />
        </div>
        {/* <div className="mb-3">
          <label htmlFor="status" className="form-label">status</label>
          <input onChange={onChange} className="form-control" id="status" name='status' />
        </div> */}
        <div className="mb-3">
          <label htmlFor="cpassword" className="form-label">Confirm Password</label>
          <input onChange={onChange} className="form-control" id="cpassword" name='cpassword' />
        </div>
        <Link to="/genrate"> <button   type="submit" className="btn btn-primary" onClick={handleSubmit}  >Submit</button></Link>
       
      </form>
    </div>
  )
}

export default Inbox
