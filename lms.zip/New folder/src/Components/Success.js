import React from 'react'


function Success() {
    
  
  
    return (
    <div>
      Congrats successfully loged in
    </div>
  )
}

export default Success
