import React,{useState} from 'react'
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';

function Genrate() {
  const navigate = useNavigate();


    const [credentials,setcredentials]=useState({email:""})
    const handlesubmit=async(e)=>{
     

      const response = await fetch(`http://192.168.128.133:5000/api/auth/gotp`, {
        method: 'POST', 
      
        headers: {
          'Content-Type': 'application/json'
        },
        
    body: JSON.stringify({email:credentials.email}) 
      });
      const json=await response.json();
    //   console.log(json);
      // response.json(json);

      if (!json.sta) {
         
        console.log("Otp Not Sent");
        // navigate('/verify');
        
        }
        else{
          navigate('/verify');
          navigate('/verify');
          console.log("OTP SENT");
            
        }

    
    }
    const onChange=(e)=>{
      setcredentials({...credentials,[e.target.name]:e.target.value})
    }



  return (
    <div>
      <input value={credentials.email}  onChange={onChange}  id="email" name='email' placeholder="email"/>
        <button onClick={handlesubmit}>sent</button>
      
    </div>
  )
}

export default Genrate
