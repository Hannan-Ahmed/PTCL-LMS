import './App.css';

import Login from './Components/Login';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Navbar from './Components/Navbar';
import Home from './Components/Home';
import Inbox from './Components/Inbox';
import Check from './Components/Check';
import Verify from './Components/Verify';
import Genrate from './Components/Genrate';
import Success from './Components/Success';
import Register from './Components/Register';

function App() {


  return (
    <div className="App">

      {/* <Login/> */}
      {/* <Inbox/> */}
      {/* <Check/> */}
<Register/>

      <Routes>
      <Route path="/" element={<Inbox/>} />
      <Route path="/check" element={<Check />} />
      <Route path="/verify" element={<Verify />} />
      <Route path="/genrate" element={<Genrate />} />
      <Route path="/success" element={<Success />} />
      </Routes>



{/* <Check/> */}




    </div>
  );
}

export default App;
